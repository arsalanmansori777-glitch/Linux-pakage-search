This project was developed as part of a Linux systems course.

The goal is to understand how different Linux package managers work by
searching packages using APT, Flatpak, and Snap.

The program takes a package name as input and displays basic search results
from each package manager using command-line tools.